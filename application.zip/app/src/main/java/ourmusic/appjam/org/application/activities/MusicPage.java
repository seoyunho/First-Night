package ourmusic.appjam.org.application.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ourmusic.appjam.org.application.R;

public class MusicPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_page);
    }
}
